# Deployment notes for Vercel

This project is a Next.js 13+ app-router TypeScript app. To deploy to Vercel:

1. Create a new Git repository and push this project.
2. In Vercel, import the Git repository.
3. Framework detection should pick **Next.js** automatically. 
4. Build command: `npm run build` (default)
5. Output directory: (leave empty) — Vercel will handle Next.js
6. No environment variables are required for RSS-based news fetching.
7. If you add API keys later (e.g., NewsAPI or Google), set them in Vercel Project Settings > Environment Variables.
8. If you get CORS or fetch errors on serverless functions, ensure `fetch` is allowed or use an external RSS-to-JSON service.

If you want me to convert RSS fetching to use a specific news API (NewsAPI, GNews) or add server-side caching with a KV store, tell me and I'll update the code.
