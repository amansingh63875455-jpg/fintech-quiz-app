import { NextResponse } from 'next/server';

// RSS Feed URLs for Indian Fintech News
const RSS_FEEDS = [
  'https://economictimes.indiatimes.com/tech/fintech/rssfeeds/63996239.cms',
  'https://bfsi.economictimes.indiatimes.com/rss/topstories',
];

interface NewsItem {
  title: string;
  link: string;
  description: string;
  pubDate: string;
  source: string;
}

let cachedNews: NewsItem[] = [];
let cacheTimestamp = 0;
const CACHE_DURATION = 12 * 60 * 60 * 1000; // 12 hours

async function parseRSSFeed(url: string): Promise<NewsItem[]> {
  const res = await fetch(url);
  const text = await res.text();

  // Simple regex-based item extraction (works for many RSS feeds)
  const itemRegex = /<item[\s\S]*?>[\s\S]*?<title>([\s\S]*?)<\/title>[\s\S]*?<link>([\s\S]*?)<\/link>[\s\S]*?(?:<description>([\s\S]*?)<\/description>)?[\s\S]*?(?:<pubDate>([\s\S]*?)<\/pubDate>)?/gi;
  const items: NewsItem[] = [];
  let match;
  while ((match = itemRegex.exec(text)) !== null) {
    const title = (match[1] || '').trim().replace(/<[^>]+>/g, '');
    const link = (match[2] || '').trim();
    const description = (match[3] || '').trim().replace(/<[^>]+>/g, '');
    const pubDate = (match[4] || '').trim();
    items.push({ title, link, description, pubDate, source: url });
  }
  return items;
}

export async function GET() {
  try {
    const now = Date.now();
    if (cachedNews.length > 0 && (now - cacheTimestamp) < CACHE_DURATION) {
      return NextResponse.json({ news: cachedNews, cached: true, lastUpdate: new Date(cacheTimestamp).toISOString() });
    }

    const allItemsArrays = await Promise.all(RSS_FEEDS.map((u) => parseRSSFeed(u).catch(() => [])));
    let allItems: NewsItem[] = ([] as NewsItem[]).concat(...allItemsArrays);

    // Deduplicate by link and sort by pubDate if available
    const seen = new Set();
    const unique = allItems.filter(item => {
      if (!item.link) return false;
      if (seen.has(item.link)) return false;
      seen.add(item.link);
      return true;
    });

    unique.sort((a,b) => {
      const da = Date.parse(a.pubDate || '');
      const db = Date.parse(b.pubDate || '');
      if (isNaN(da) && isNaN(db)) return 0;
      if (isNaN(da)) return 1;
      if (isNaN(db)) return -1;
      return db - da;
    });

    const topNews = unique.slice(0, 20);
    cachedNews = topNews;
    cacheTimestamp = now;

    return NextResponse.json({
      news: topNews,
      cached: false,
      lastUpdate: new Date(cacheTimestamp).toISOString(),
    });
  } catch (error) {
    console.error('Error fetching news:', error);
    return NextResponse.json({ error: 'Failed to fetch news' }, { status: 500 });
  }
}
